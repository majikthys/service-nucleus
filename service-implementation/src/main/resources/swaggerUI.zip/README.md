# Static Swagger JSON 
====

To share static swagger json please make the contents of this folder available on a web server and direct an installation of SwaggerUI (such as included in project src at src/main/webapp/ui/swagger-ui) to load service.json




